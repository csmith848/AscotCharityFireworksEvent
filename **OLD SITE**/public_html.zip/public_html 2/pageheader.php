<?php
require_once 'logic.php';
?>
<!-- page header section -->
  <table cellpadding="0" cellspacing="0" border="0">
    <tr>
	    <td class="top">
	      <a href="http://www.roundtable.co.uk"><img src="images/rtlogo.gif" ALT="Round Table Logo"></a>
	      <br>
	      <a href="http://www.ascot.co.uk" target="_blank"><img src="images/smallascotrcltd.gif" ALT="Ascot Racecourse Ltd"></a>
	    </td>
      <td>
        <img src="images/smallrocket.gif" alt="rocket">
	    </td>
	    <td>
	      <h2><a class="head" href="http://www.ascotroundtable.org.uk">Ascot Round Table</a></h2>
	      <h4>presents</h4>
	      <h1 itemprop="name">ASCOT CHARITY FIREWORKS EVENT</h1>
	      <h3>Saturday <?php echo $dispdate.$dispstndth.' '.$dispmonth; ?></h3>
	    </td>
	    <td>
	      <img src="images/smallrockets.gif" alt="rocket">
	    </td>
	    <td></td>
	    <td>
	      <img src="images/starfireworks.gif" alt="Star Fireworks">
	    </td>
	  </tr>
  </table>
